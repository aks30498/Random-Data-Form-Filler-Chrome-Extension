jQuery(document).ready(function($){
var length = 7;
function rand_text(){
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for(var i = 0; i < length; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}
function random_interval(min,max)
{   var x= Math.floor(Math.random()*(max-min+1)+min);
    if(x-10<0){
      return "0"+x;
    }
    return x;
}

    //inputs
    var inp = $(document).find("input:visible");
    for(var i=0;i<inp.length;i++){

      switch($(inp[i]).prop('type')){
        case "text":
        inp[i].value=rand_text();
        break;

        case "password":
        inp[i].value=rand_text();
        break;

        case "date":
        var end = new Date();
        var start = new Date(1990,0,1);
        var date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
        var month = date.getMonth()+1;
        if(month<10){month = "0"+month;}
        var day = date.getDate()+1;
        if(day<10){day = "0"+day;}
        var date_string = date.getFullYear()+"-"+month+"-"+day;
        inp[i].value=date_string;
        break;

        case "time":
        var min = $(inp[i]).prop("min")==""?"00:00".split(":"):$(inp[i]).prop("min").split(":");
        var max = $(inp[i]).prop("max")==""?"23:59".split(":"):$(inp[i]).prop("max").split(":");
        inp[i].value=random_interval(parseInt(min[0]),parseInt(max[0]))+":"+random_interval(parseInt(min[1]),parseInt(max[1]));
        break;

        case "email":
        inp[i].value=rand_text()+"@"+rand_text()+".com";
        break;

        case "number":
        if($(inp[i]).prop("placeholder")!=="" && $(inp[i]).prop("placeholder").split(" ")[1]=="Digit" && !(isNaN($(inp[i]).prop("placeholder").split(" ")[0]))){
          var num_length = parseInt($(inp[i]).prop("placeholder").split(" ")[0]);
        //  alert($(inp[i]).prop("placeholder"));
          var rand = 0;
          while((rand = Math.random())==1){
            continue;
          }
          $(inp[i]).val(Math.floor(Math.pow(10,num_length-1) + rand * 9*Math.pow(10,num_length-1)));
          break;
        }
        if($(inp[i]).prop("min")!==""){
          var min = parseInt($(inp[i]).prop("min"));
        }else{
          var min =0;
        }

        if($(inp[i]).prop("max")!==""){
          var max = parseInt($(inp[i]).prop("max"));
        }else{
          var max = min+100;
        }
        var rand=0;
        while((rand = Math.random())==0){
          continue;
        }
        $(inp[i]).val(Math.floor(min + rand * max));
        break;

        case "checkbox":
          if(Math.round(Math.random())==1){
            //alert("yes");
            $(inp[i]).prop("checked",true);
          }else{
            //alert("nope");
            $(inp[i]).prop("checked",false);
          }
        break;

        case "radio":
          if(Math.round(Math.random())==1){

            $(inp[i]).prop("checked",true);
          }else{
            
            $(inp[i]).prop("checked",false);
          }
        break;

      }
    }
    //textareas
    var txt = document.querySelectorAll("textarea");
    for(var i=0;i<txt.length;i++){
        txt[i].value=rand_text();
    }

    var sel = document.querySelectorAll("select");
    for(var i=0;i<sel.length;i++){
      sel[i].selectedIndex=""+Math.floor(Math.random() * sel[i].length);
      $(sel[i]).trigger("change");
    }
});

chrome.runtime.onMessage.addListener(function(message, sender, response){
  if(message=="trigger"){

var s = document.createElement('script');
s.src = chrome.extension.getURL('autofill.js');
(document.head||document.documentElement).appendChild(s);
s.onload = function() {
    s.parentNode.removeChild(s);
};

}
});

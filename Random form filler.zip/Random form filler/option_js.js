$("#mail").on('click',function(){
  window.location.href= "mailto:aksharma30498@gmail.com?Subject=Here%20is%20a%20suggestion";
  alert("Opening Mail app...Please wait!");
})
$("#back").on('click',function(){
  $("#guide").hide();
  $("#options").fadeIn(700);
})
$("#manual").on('click',function(){
  $("#options").hide();
  $("#guide").fadeIn(700);
})
